// module express
var express = require('express');
var app = express();
// module mã hoá urlencoded với body-parser
var bodyParser = require('body-parser');
var postgre = require('pg');
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
var urlencodedParser = bodyParser.urlencoded({limit: '50mb',extended :false});
// khai báo biến port để xác định port kết nối ở server và local
var port = process.env.PORT || 3000;
// khai báo biến connectionString để xác định thông tin kết nối database
var connectionString = process.env.DATABASE_URL || "postgresql://postgres:nkok2305@@:5432/postgres"

// khởi tạo server node lắng nghe trên cồng port
app.listen(port, function(){
console.log("dang lang nghe tren port 3000");
})

  postgre.connect(connectionString,function(err, client, done){
    if(err) {
            console.log(err);
            return res.status(500).json({ success: false, data: err});
          }
          else{
// route cơ bản với phương thức get
            app.get("/",function(req,res){
              console.log("co nguoi ket noi!")
              var id = req.query.id
              console.log(id)
              res.send(id)
            })

            app.post("/record",urlencodedParser,function(req,res){

            console.log("ket noi thanh cong!");

            idRecord = req.body.idRecord
            strRecord = req.body.strRecord

// Thêm thông tin file record với 2 thông số là id Record và strRecord
            var query = client.query("INSERT INTO record VALUES('"+idRecord+"','"+strRecord+"');");

            query.on('end', function() {
            //done();
            console.log("thanh cong");
            res.send(strRecord)
            //return res.json(results);
            })
          });
// Lấy toàn bộ data id của các file record đã lưu trên database
          app.get("/data",function(req,res){

            var results = [];

            console.log("lay data thanh cong!");
            var query = client.query("SELECT idRecord FROM record;")
            query.on('row', function(row) {
            results.push(row);
              });
            query.on('end',function(){
              //done();
              return res.json(results)
            })
          })
// Lấy thông tin chi tiết của file record sử dụng get truyền thông số
          app.get("/chitiet",function(req,res){
            console.log("lay data thanh cong!");
            let rowdata = ""
            let id = req.query.id
            var query = client.query("SELECT strRecord FROM record WHERE idRecord='"+id+"';")
            query.on('row', function(row) {
            rowdata = row;
              });
            query.on('end',function(){
              //done();
              return res.json(rowdata)
            })
          })

          }
  })
