//
//  ViewController.swift
//  record
//
//  Created by datnguyen on 8/11/16.
//  Copyright © 2016 datnguyen.com. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController,AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    
    var player:AVAudioPlayer?
    var record:AVAudioRecorder?
    
    @IBOutlet var tblView: UITableView!
    
    var arrID:Array<Int> = []
    
    @IBAction func abtnPlay(_ sender: AnyObject) {
        record!.record()
    }
    
    @IBAction func abtnPause(_ sender: AnyObject) {
        if record!.record() == true{
            record?.stop()
        }
    }
    func update(){
        sldTimer.value = Float((player?.currentTime)!)
        print("aaaa")
    }
    var timer:Timer = Timer()
    
    @IBAction func Play(_ sender: AnyObject) {
        //do{
           // player = try AVAudioPlayer(contentsOf: (record?.url)!)
            do{
                let data = try Data(contentsOf: (record?.url)!)
                let st = data.base64EncodedString()
                //let para = "text=\(st)"
                //print(st)
                let rand:Int = Int(arc4random()%1000)
                let para = "idRecord=\(rand)&strRecord=\(st)"
                let datapara = para.data(using: String.Encoding.utf8)
                let url = URL(string: "http://localhost:3000/record")
                var req = URLRequest(url: url!)
                req.httpMethod = "POST"
                req.httpBody = datapara
                let session = URLSession.shared
                session.dataTask(with: req, completionHandler: { (data, res, err) in
                    DispatchQueue.main.async {
                            self.load()
                    }
                }).resume()
                //print(st)
            }catch{}
    }
    
    
    @IBOutlet var sldTimer: UISlider!
    
    func load(){
        let url = URL(string: "http://localhost:3000/data")
        let req = URLRequest(url: url!)
        let session = URLSession.shared
        session.dataTask(with: req, completionHandler: { (data, res, err) in
            print(data!)
            do{
                let result:Array<Dictionary<String,AnyObject>> = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! Array<Dictionary<String, AnyObject>>
                self.arrID = []
                for i in result{
                    self.arrID.append(i["idrecord"] as! Int)
                }
                DispatchQueue.main.async {
                    self.tblView.reloadData()
                }
                
            }catch{
                print("that bai!")
            }
        }).resume()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        load()
        
        tblView.dataSource = self
        tblView.delegate = self
        
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let docs = dirPath[0]
        let soundPath = docs.appending("/record.caf")
        
        let soundFile = NSURL(fileURLWithPath: soundPath)
        
        let recordSetting = [AVEncoderAudioQualityKey:AVAudioQuality.min.rawValue,AVEncoderBitRateKey:16,AVNumberOfChannelsKey:2,AVSampleRateKey:2]
        
        let audioSession = AVAudioSession.sharedInstance()
        print(audioSession)
        do{
            try audioSession.setCategory(AVAudioSessionCategoryPlayAndRecord)
            do{
                record = try AVAudioRecorder(url: soundFile as URL, settings: recordSetting)
            }catch{}
        }catch{}
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

extension ViewController:UITableViewDataSource,UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrID.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell?.textLabel?.text = String(arrID[indexPath.row])
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let url = URL(string: "http://localhost:3000/chitiet?id=\(arrID[indexPath.row])")
        let req = URLRequest(url: url!)
        let session = URLSession.shared
        session.dataTask(with: req, completionHandler: { (data, res, err) in
            //print(data!)
            do{
                let result:Dictionary<String,String> = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! Dictionary<String, String>
                let dataString = result["strrecord"]
                let stringPre = dataString?.replacingOccurrences(of: " ", with: "+")
                //print(stringPre)
                //let data2 = Data(base64Encoded: stringPre!)
                let data3 = Data(base64Encoded: stringPre!, options: NSData.Base64DecodingOptions.ignoreUnknownCharacters)
                //print(data3)
                self.player = try AVAudioPlayer(data: data3!)
                self.player?.play()
                DispatchQueue.main.async {
                    self.sldTimer.minimumValue = 0
                    self.sldTimer.maximumValue = Float((self.player?.duration)!)
                    self.timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(ViewController.update), userInfo: nil, repeats: true)
                }
                
            }catch{
                print("that bai!")
            }
        }).resume()

    }
}

